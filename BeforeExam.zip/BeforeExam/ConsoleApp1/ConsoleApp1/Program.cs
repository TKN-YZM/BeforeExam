﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Soru 1: Mükemmel sayının kodlamasnı yapınız 

            //Mükemmel Sayı
            //Kural: Bir sayının kendisi hariç bölenlerinin toplamı o kendisine eşit olmalı
            //Örnek 6,  1-2-3 sayılarına bölünür 3+2+1=6 || örnek 28, 1+2+4+7+14=28   

            //Try catch kullanıyoruz çünkü kullanıcı rakam dışı girdi girerse rogram göçecektir.

            try
            {
                Console.Write("Sayı giriniz: ");        //ilk kullanıcıdan sayı alıyoruz
                int sayi = Convert.ToInt32(Console.ReadLine());      //int.Parse(Console.Readline()) ile de yapılabilir

                int toplam = 0;      //Aldığımız sayının bölenlerini toplamak için burda toplam değişkenini oluşturduk

                for (int i = 1; i < sayi; i++)      //Aldığımız sayının bölenlerini bulmak için döngü oluşturuyoruz 
                {
                    if (sayi % i == 0)              //Aldığımız sayıya tam bölünen sayının kontrolünü yapıyoruz  
                    {
                        toplam += i;                
                    }
                }

                if (sayi == 0)              //0 sayısı döngüye girmez çünkü i=1>sayi=0 , toplam da 0 olunca program mükemmel sayı sanar     
                {                                  
                    Console.WriteLine("Girile sayı mükemmel bir sayı DEGILDIR"); 
                }
                else if (toplam == sayi)            //Eğer toplam ,alınan sayiya eşitse mükemmel sayıdır
                {
                    Console.WriteLine("Girilen sayı Mükemmel bir sayıdır");
                }
                else
                {
                    Console.WriteLine("Girilen sayı Mükemmel bir sayı DEGILDIR");
                }
            }
            catch (Exception)
            {
                Console.WriteLine("Lütfen sadece tam sayı giriniz");
            }
            


        }
    }
}
